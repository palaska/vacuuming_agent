%initial state of the environment and the agents location

%active test case
location(a,dirty).
location(b,dirty).
location(c,clean).
location(d,dirty).

agentat(b).


%commented test case 1
%location(a,clean).
%location(b,clean).
%location(c,clean).
%location(d,dirty).
%
%agentat(b).


%commented test case 2
%location(a,dirty).
%location(b,clean).
%location(c,dirty).
%location(d,clean).
%
%agentat(a).
